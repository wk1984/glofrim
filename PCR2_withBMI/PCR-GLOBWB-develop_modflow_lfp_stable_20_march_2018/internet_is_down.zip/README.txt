PCR-GLOBWB git repository.

PCR-GLOBWB (PCRaster Global Water Balance) Global Hydrological Model

Copyright (C) 2016, Ludovicus P. H. (Rens) van Beek, Edwin H. Sutanudjaja, Yoshihide Wada,
Joyce H. C. Bosmans, Niels Drost, Inge E. M. de Graaf, Kor de Jong, Patricia Lopez Lopez,
Stefanie Pessenteiner, Oliver Schmitz, Menno W. Straatsma, Niko Wanders, Dominik Wisser,
and Marc F. P. Bierkens,
Faculty of Geosciences, Utrecht University, Utrecht, The Netherlands

PCR-GLOBWB is released under the GPL license, version 3

This program comes with ABSOLUTELY NO WARRANTY

See the "LICENSE" file for more information.

For questions, please contact Edwin Sutanudjaja (e-mail: E.H.Sutanudjaja@uu.nl).

Some git reference cards:
- https://help.github.com/articles/git-cheatsheet
- http://devcheatsheet.com/tag/git/

A cookbook about how to run PCR-GLOBWB and contribute to its development: 
- https://goo.gl/medqhJ (created on May 2014).
- Examples of model input files can be obtained from git@github.com:UU-Hydro/PCR-GLOBWB_input_example.git (including ini files). 
