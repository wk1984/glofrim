PCR-GLOBWB
==========

PCR-GLOBWB (PCRaster Global Water Balance) is a large-scale hydrological model intended for global to regional studies and developed at the Department of Physical Geography, Utrecht University (Netherlands).

contact: Edwin Sutanudjaja (E.H.Sutanudjaja@uu.nl).

Please also see the file README.txt.
